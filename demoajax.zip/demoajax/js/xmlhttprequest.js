//obtener referencia a la caja de texto
let cajaMensaje = document.getElementById("cajaNombre")

//obtener referencia al boton
let botonMensaje = document.getElementById("botonMensaje")

//obtener referencia a caja de resultados
let resultados = document.getElementById("resultados");

//definir oyente de eventos de clic sobre el boton
botonMensaje.addEventListener("click", procesarMensaje)

//asignar el foco a la caja de texto
cajaMensaje.focus()

//escribir funcion javascript para procesar peticion ajax
function procesarMensaje() {
    //obtiene el dato ingresado en la caja de datos
    let datoCaja = cajaMensaje.value;

    if (datoCaja.trim() === ""){
        resultados.innerHTML = "Debe ingresar un nombre...";
        cajaMensaje.focus()
    }else{
        //peticion ajax

        //1 Crear objeto XMLHttpRequest
        let xhttp = new XMLHttpRequest();

        //2 Controlar envio de la peticion
        xhttp.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                resultados.innerHTML = this.responseText;
            }
        };

        //3 configurar envio de la petición
        xhttp.open(
            "GET",
            "http://localhost:8080/mensaje/" + datoCaja,
            true
        );

        //4 Enviar la peticion
        xhttp.send();
    }
    
}