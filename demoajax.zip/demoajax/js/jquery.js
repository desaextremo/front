//obtener referencia a la caja de texto
let cajaMensaje = document.getElementById("cajaNombre")

//obtener referencia al boton
let botonMensaje = document.getElementById("botonMensaje")

//obtener referencia a caja de resultados
let resultados = document.getElementById("resultados");

//definir oyente de eventos de clic sobre el boton
botonMensaje.addEventListener("click", procesarMensaje)

//escribir funcion javascript para procesar peticion ajax
function procesarMensaje() {
    //obtiene el dato ingresado en la caja de datos
    let datoCaja = cajaMensaje.value;

    if (datoCaja.trim() === "") {
        resultados.innerHTML = "Debe ingresar un nombre...";
        cajaMensaje.focus()
    } else {
        $.ajax({
            url: 'http://localhost:8080/mensaje/' + datoCaja,
            type: 'GET',
            success: function (respuesta) {
                console.log(respuesta)
                 //Obtiene respuesta y la agrega a la sección de la pagina
                 resultados.innerHTML = respuesta.responseText;
            },
            error: function (xhr, status) {
                console.log("error " + xhr)
            },
            complete: function (xhr, status) {
            }
        });
    }
}