traerdatos()

/* Funcion para listar carros*/
function traerdatos() {
    let registros = ""
    let id = ""

    let xhttp = new XMLHttpRequest();
    let salida = "<strong>Texto del mensaje :</strong>";

    xhttp.onreadystatechange = function () {
        if (this.readyState == 4 && this.status == 200) {
            let respuesta = JSON.parse(this.responseText);
            console.log("entre")

            for (let i in respuesta.items) {
                id = respuesta.items[i].id
                console.log("id: " + respuesta.items[i].id)
                console.log("brand: " + respuesta.items[i].brand)
                console.log("model: " + respuesta.items[i].model)
                console.log("category_id: " + respuesta.items[i].category_id)

                registros += "<tr>\
                        <th scope=\"row\">" + respuesta.items[i].id + "</th>\
                        <td>" + respuesta.items[i].brand + "</td>\
                        <td>" + respuesta.items[i].model + "</td>\
                        <td>" + respuesta.items[i].category_id + "</td>\
                        <td>\
                             <button class=\"btn btn-outline-dark\" onclick=\"editar(" + id + ")\">Modificar Juego</button>\
                            <button class=\"btn btn-outline-dark\" onclick=\"eliminar(" + id + ")\">Borrar Juego</button>\
                        </td>\
                        </tr>"

            }

            document.getElementById("registros").innerHTML = registros;
        }
    };
    xhttp.open(
        "GET",
        "https://apex.oracle.com/pls/apex/auxiliarg3/car/car",
        true
    );
    xhttp.send();
}