//Definicion de variables
//Variables globales: reconocidas dentro de todo el script

//La variable url se utiliza para indicar la  url en donde se encuentra el api (modulo/plantilla de oracle cloud)
//y asi poder gestionar peticiones a los manejadores
let url="https://ga04e7f1d8aef52-apexdemo.adb.us-phoenix-1.oraclecloudapps.com/ords/admin/car/car"

//Acceder a un elemento html que se identifica por un id
let seccionNuevo = document.getElementById("nuevo")
let seccionEditar = document.getElementById("editar")
let seccionEliminar = document.getElementById("eliminar")
let seccionListar = document.getElementById("listar")
let botonNuevoCarro = document.getElementById("botonNuevoCarro")
let bottonCancelarNuevo = document.getElementById("bottonCancelarNuevo")
let bottonCancelarEditar = document.getElementById("bottonCancelarEditar")
let bottonCancelarEliminar = document.getElementById("bottonCancelarEliminar")
let botonAplicarEditarCarro = document.getElementById("botonAplicarEditarCarro")
let botonAplicarEliminarCarro = document.getElementById("botonAplicarEliminarCarro")
let botonAplicarNuevoCarro = document.getElementById("botonAplicarNuevoCarro")
let tableBody = document.getElementById("tableBody")
//almacena html de los registros a presentar en el listado de carros <tr><td>....</td></td></tr>
let resultados = ""

//Gestores de eventos
//para el procesamiento de eventos click
botonNuevoCarro.addEventListener("click",nuevoCarro)
bottonCancelarNuevo.addEventListener("click",inicial)
bottonCancelarEditar.addEventListener("click",inicial)
bottonCancelarEliminar.addEventListener("click",inicial)
botonAplicarEditarCarro.addEventListener("click",aplicarEditarCarro)
botonAplicarEliminarCarro.addEventListener("click",aplicarEliminarCarro)
botonAplicarNuevoCarro.addEventListener("click",aplicarNuevoCarro)

//se ejecuta cuando inicia la aplicación para establecer el estado inicial de la pagina
inicial()

/**
 * Configura el aspecto inicialo de la pagina ocultando las secciones:'nuevo', 'editar', y 'eliminar'
 * y dejando visible la seccion 'listar'. Adcionalmente ejecuta LA FUNCION 'listar()' para obtener los
 * carros disponibles en la base de datos.
 */
function inicial(){
    seccionNuevo.style.display="none"
    seccionEditar.style.display="none"
    seccionEliminar.style.display="none"
    listar()
}

//definicion de funciones

//1 funciones que configuran el aspecto de la pagina

/**
 * Configurar la interfaz para que presente el formulario que permitira la captura de un nuevo carro
 * dejando visible la secion 'nuevo', y ocultando las secciones:'editar', 'eliminar' y listar
 */
function nuevoCarro(){
    seccionNuevo.style.display="block"
    seccionEditar.style.display="none"
    seccionEliminar.style.display="none"
    seccionListar.style.display="none"
    document.getElementById("idCar").focus()
}

/**
 * Configurar la interfaz para que presente el formulario que permitira la edicion de un carro
 * seleccionado dejando visible la secion 'editar', y ocultando las secciones:'nuevo', 'eliminar' y listar
 * Invoca la funcion 'recuperarInformacionCarro' para  obtener datos del carro cuyo id corresponde
 * con el valor del parametro 'id'. Esta funcion recibe como parametros el valor del id y los nombres de
 * los id asociados a los campos id, brand, model y category
 * 
 * @param {*} id id, identificador o llave primaria del carro 
 */
function editarCarro(id){
    seccionNuevo.style.display="none"
    seccionEditar.style.display="block"
    seccionEliminar.style.display="none"
    seccionListar.style.display="none"
    
    recuperarInformacionCarro(id,'idEditCar','brandEditCar','modelEditCar','categoryEditCar')

    //asigna el foco en el campo brand
    document.getElementById('brandEditCar').focus()
}

/**
 * Configurar la interfaz para que muestre el formulario que permitira con informacion del carro a eliminar
 * dejando visible la secion 'eliminar', y ocultando las secciones:'nuevo', 'editar' y listar
 * Invoca la funcion 'recuperarInformacionCarro' para  obtener datos del carro cuyo id corresponde
 * con el valor del parametro 'id'. Esta funcion recibe como parametros el valor del id y los nombres de
 * los id asociados a los campos id, brand, model y category
 * 
 * @param {*} id id, identificador o llave primaria del carro 
 */
function borrarCarro(id){
    seccionNuevo.style.display="none"
    seccionEditar.style.display="none"
    seccionEliminar.style.display="block"
    seccionListar.style.display="none"

    recuperarInformacionCarro(id,'idDeleteCar','brandDeleteCar','modelDeleteCar','categoryDeleteCar')
}

//2 Funciones que realizan peticiones ajax a los servicios con la libreria axios

/**
 * Listar carros: peticion get:
 * Ejecuta peticion ajax para consumer servicio web con peticion 'get' para recuperar información
 * de los carros existentes en la base de datos. Finalmente recorre el arreglo de datos o resultado
 * obtenido en un ciclo repetitivo 'for',  va concatenando esta respuesta en la variable 'resultados'
 * y finalmente usa: tableBody.innerHTML = resultados  para afectar el contenido del elemento 
 * <tbody id="tableBody">registros en la variable 'resultados'</tbody>
 */
function listar(){
    resultados=""
    axios.get(url)
    .then(function (response){

        //console.log("todos los datos de respuesta: " + response.data)
        //de la respuesta obtengo solamente el arreglo de items o carros
        let items = response.data.items

        //console.log("solo los datos de los carros: " + items)

        //recorro el arreglo de carros y voy generando <tr>datos del carro...</tr>
        for(let i in items){
            //console.log("id: " + items[i].id)
            //console.log("marca: " + items[i].brand)
            //console.log("modelo: " + items[i].model)
            //console.log("categoria: " + items[i].category_id)

            resultados +=  '<tr>' + 
                            '<td>' + items[i].id + ' </td>' + 
                            '<td>' + items[i].brand +'</td>' +
                            '<td>' + items[i].model +'</td>' +
                            '<td>' + items[i].category_id +'</td>' +
                            '<td colspan="2">' +
                            '    <button class="btn btn-outline-primary" onclick="editarCarro(' +  items[i].id + ')">Editar</button>' +
                            '    <button class="btn btn-outline-primary" onclick="borrarCarro(' +  items[i].id + ')">Eliminar</button>' +
                            '</td>' + 
                        '</tr>'
        }
        tableBody.innerHTML = resultados
        seccionListar.style.display="block"
        
    })
    .catch(function (error){
        console.log(error)
    })
}

/**
 * Recupera la información de un carro a partir de su id:
 * invoca al servicio web con peticion get, enviando el id como parametro
 * ej:  https://ga04e7f1d8aef52-apexdemo.adb.us-phoenix-1.oraclecloudapps.com/ords/admin/car/car/6
 * Recibe el valor del id o identificador del carro y los nombres de los id sobre los que asignara los valores
 * obtenidos como resultado de ejecutar el servicio web
 * @param {*} id id, identificador o llave primaria del carro 
 * @param {*} idName Nombre del id asociado al campo id 
 * @param {*} brandName  Nombre del id asociado al campo brand 
 * @param {*} modelName Nombre del id asociado al campo model
 * @param {*} categoryName  Nombre del id asociado al campo category
 */
function recuperarInformacionCarro(id,idName,brandName,modelName,categoryName){
     //peticion http de tipo get
     axios.get(url + "/" + id)
     .then(function (response) {
       let items = response.data.items
   
       console.log(response.data)
       document.getElementById(idName).value = items[0].id
       document.getElementById(brandName).value = items[0].brand                                                   
       document.getElementById(modelName).value = items[0].model
       document.getElementById(categoryName).value = items[0].category_id
     })
}


/**
 * Invoca ws para actualizar el carro, adicionalmente al terminar invoca funcion para regresar la pantalla a su estado inicial
 */
function aplicarEditarCarro() {
    //leer informacion del carro editado o modificado
    let idEditCar = document.getElementById("idEditCar").value
    let brandEditCar = document.getElementById('brandEditCar').value
    let modelEditCar = document.getElementById('modelEditCar').value
    let categoryEditCar = document.getElementById('categoryEditCar').value
  
    axios.put(url, {
      id: idEditCar,
      brand: brandEditCar,
      model: modelEditCar,
      category_id: categoryEditCar
  })
    .then(function (response) {
      console.log(response.data);
      //actualizar tabla de datos
      inicial()
    })
    .catch(function (error) {
      // manejar error
      console.log(error);
    })
  }

  /**
   * Invoca ws para eliminar el carro, invocando servicio web con peticion DELETE,
   * adicionalmente al terminar invoca funcion para regresar la pantalla a su estado inicial
   */
  function aplicarEliminarCarro(){
    //leer informacion del carro editado o modificado
    let idDeleteCar = document.getElementById("idDeleteCar").value
  
    axios.delete(url, {data: { id: idDeleteCar } })
    .then(function (response) {
      console.log(response.data);
      //actualizar tabla de datos
      inicial()
    })
    .catch(function (error) {
      // manejar error
      console.log(error);
    })
  }
  
  /**
   * Invoca ws para ingresar un nuevo carro, invocando servicio web con peticion POST, 
   * adicionalmente al terminar invoca funcion para regresar la pantalla a su estado inicial
   */
  function aplicarNuevoCarro(){
    //leer informacion del carro editado o modificado
    let idCar = document.getElementById("idCar").value
    let brandCar = document.getElementById('brandCar').value
    let modelCar = document.getElementById('modelCar').value
    let categoryCar = document.getElementById('categoryCar').value
  
    axios.post(url, {
      id: idCar,
      brand: brandCar,
      model: modelCar,
      category_id: categoryCar
  })
    .then(function (response) {
      console.log(response.data);
      //actualizar tabla de datos
      inicial()
      
    })
    .catch(function (error) {
      // manejar error
      console.log(error);
    })
  }
