package com.atenea.rentacarg5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiciosWebRentACarYOtrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
