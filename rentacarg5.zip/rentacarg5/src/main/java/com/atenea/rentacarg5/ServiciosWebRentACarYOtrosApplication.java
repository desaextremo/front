package com.atenea.rentacarg5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiciosWebRentACarYOtrosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiciosWebRentACarYOtrosApplication.class, args);
	}

}
