package com.atenea.rentacarg5.controller;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class DemoController {
    //http://localhost:8080/mensaje/lucas
    @GetMapping("/mensaje/{nombre}")
    public String mensaje(@PathVariable("nombre") String nombre){
        return "Hola " + nombre;
    }
}
